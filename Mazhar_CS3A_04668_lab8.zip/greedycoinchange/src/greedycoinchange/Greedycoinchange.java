/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package greedycoinchange;
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author test1
 */
public class Greedycoinchange {

    /**
     * @param args the command line arguments
     */
    
    //using greedy approach
    public static int change(int amount){
        int []coin ={25, 10, 5, 1};
        int numdenoms=0;
        int outdenoms = 0;
        //int []outdenoms = new int[2];
        //int counter = 1;
        //System.out.print(outdenoms.length);
        if(amount<=0){
            System.out.print("No denominations available.");
        }
        else{
        for(int i=0; i<coin.length; i++){
            if(amount>=coin[i]){
            numdenoms = amount/coin[i];
            outdenoms =outdenoms+ numdenoms;
            System.out.print(numdenoms+ " "+ coin[i]+"\n");
            amount = amount - coin[i]*numdenoms; 
            
            }
            }
         }
       
        return outdenoms;
    }        
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        int amount=0;
         System.out.print("Enter amount to be changed...");
        Scanner in = new Scanner(System.in);
        amount = in.nextInt();
       
        
        change(amount);
    }
    
}
