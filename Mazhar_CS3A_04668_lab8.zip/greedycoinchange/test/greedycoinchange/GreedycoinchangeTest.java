/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package greedycoinchange;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author test1
 */

public class GreedycoinchangeTest {
    
    
    public GreedycoinchangeTest() {
        
    }
    
    @Test
    public void Test(){
    int amount = 63;
    int expected = 6;   
    assertEquals(expected, Greedycoinchange.change(amount));
    
    
    int amount1 = 33;
    int expected1 = 5;
    assertEquals(expected1, Greedycoinchange.change(amount1));

    }
}
