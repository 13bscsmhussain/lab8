/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dynamicchange;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Mazhar Hussain Awan
 */
public class DynamicchangeTest {
    
    public DynamicchangeTest() {
    }
    
    @Test
    public void Test(){
    int amount = 53;
    int expected = 5;   
    assertEquals(expected, Dynamicchange.dynamiccoinchange(amount));
    
    int amount1 = 33;
    int expected1 = 5;   
    assertEquals(expected1, Dynamicchange.dynamiccoinchange(amount1));
    
    }
    
}
