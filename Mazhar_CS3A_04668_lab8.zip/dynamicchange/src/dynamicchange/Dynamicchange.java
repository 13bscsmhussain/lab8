/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dynamicchange;
import java.util.Scanner;
/**
 *
 * @author Mazhar Hussain Awan
 */
public class Dynamicchange {

    /**
     * @param args the command line arguments
     */
    
    public static int dynamiccoinchange(int amount) {
        int[] coin  = {1,5, 10, 25};
        int[] min_coins_array = new int[amount + 1];
        min_coins_array[0] = 0;
        
        int minimum;
        
        for (int j = 1; j <= amount; j ++) {
            minimum = Integer.MAX_VALUE;
            
            for (int i = 0; i < coin .length; i ++) {
                if (coin [i] <= j) {
                    if (1 + min_coins_array[j - coin [i]] < minimum) {
                        minimum = 1 + min_coins_array[j - coin [i]];
                    }
                }
            }
            
            min_coins_array[j] = minimum;
        }
        
        return min_coins_array[amount];
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        int amount=0;
        System.out.print("Enter amount to be changed...");
        Scanner in = new Scanner(System.in);
        amount = in.nextInt();
       
        
        int  denoms = dynamiccoinchange(amount);
        System.out.print(denoms);
    }
    
}
